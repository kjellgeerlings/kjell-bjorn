<html> 

<head> 
Mijn Web project
</head>
<body>
    <h1>Veel Verschillende projecten bij elkaar</h1>
    <!--opdracht 1-->
    <a href="nextsite1.html">kijk wat er zal gebeuren</a>
    <br>
    <a href="nextsite2.html">kijk wat er zal gebeuren (maar anders)</a>
    <br>
    <a href="mapsite.html">map</a>
    <br>
    <a href="tablesite.html">TOURNAMENT</a>
    <br>
    <a href="lijstje.html">THE LIST</a>
    <br>
    <a href="youtubesite.html">filmpje</a>
    <br>
    <a href="div.html">The Entire Bee Movie Script Abridged</a>
</body>




</html>
